﻿<p>该舵机驱动板可以同时驱动32个sg90或者mg90s小型舵机。</p>
<p>只要是电压在5V的pwm舵机都可以驱动。</p>
<p>项目可以自由复制，分享。</p>
<p>如果将其用于商业用途，可以直接用。</p>            
How to use：

At editor, open the document via: Top menu - File - Open - EasyEDA... , and select the json file, then open it at the editor, you can save it into a project.


如何使用：

打开编辑器，通过：顶部菜单 - 文件 - 打开 - 立创EDA... ，选择 json 文件打开在编辑器，你可以保存文档进工程里面。